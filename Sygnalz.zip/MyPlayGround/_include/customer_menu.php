<div class="menu">
                    <ul>
      
                    <li><a href="customer.php">Create Campaign Tasks</a></li>
                    <li><a href="">Settings</a></li>
                    </ul>
</div>     
