<div class="header">
    <div class="logo"><a href="#"><h1>LOGO HERE</h1></a></div>
    
    <div class="right_header">Welcome <b><?php echo $_SESSION['name']; ?></b> | <a href="#" class="messages">(3) Messages</a> | <a href="index.php" class="logout">Logout</a></div>
    <div id="clock_a"></div>
</div>

