<div class="menu">
                    <ul>
                    <li><a href="admin.php">Manage Users</a></li>
                    <li><a href="manage_campaign.php">Manage Campaigns</a></li>
                    <li><a href="manage_customer.php">Manage Customer</a></li>
                    <li><a href="manage_vendor.php">Manage Vendor</a></li>
                    <li><a href="problem_holding.php">Problem Holding Area <span class="problemCountDisplay"><?php echo $componentsCreator->queryCountProblem(); ?></span></a></li>
                    <li><a href="manage_payment.php">Manage Vendor Payment </a></li>
                    <li><a href="">Settings</a></li>
                    </ul>
</div>     
