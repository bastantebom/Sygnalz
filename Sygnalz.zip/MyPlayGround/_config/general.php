<?php
	//BASIC INFORMATION
	define("COMPANY_NAME", "Sygnalz");
	define("COMPANY_ADDRESS", "");
	//DATABASE CONNECTION
	define("USERNAME", "root");
	define("PASSWORD", "mysql");
	define("HOST", "localhost");
	define("DATABASE_NAME", "sygnalz_db");
	
	//DIRECTORIES
	define("IMAGE_DIR" ,"_image");
	define("VIEW_LIBRARIES", "_libraries");
	
	//CSS
	define("CSS_DIR", "_css");
	
	//JAVASCRIPT
	define("JAVASCRIPT_DIR", "_js");
	define("JQUERY_DIR", "_jquery");
        
        //SECURITY
       
?>